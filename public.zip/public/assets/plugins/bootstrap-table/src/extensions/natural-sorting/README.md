# Table Natural Sorting

Use Plugin: [bootstrap-table-natural-sorting](https://github.com/wenzhixin/bootstrap-table/tree/master/src/extensions/natural-sorting)

## Usage

```html
<script src="extensions/natural-sorting/bootstrap-table-natural-sorting.js"></script>
```

### Options

* Just add data-sorter="alphanum" to any th